#pragma once

#pragma region Local Dependencies

#include "Scene.h"

#pragma endregion

class $safeitemname$ : public Scene {
public:
	void OnInitialize() override;
	void OnEvent(const sf::Event& event);
	void OnUpdate();
};